<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class login_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    public function get($user_id = null)
    {
        if (!is_null($user_id)) {
            $query = $this->db->select('*')->from('registration')->where('user_id', $user_id)->get();
            if ($query->num_rows() === 1) {
                return $query->row_array();
            }
            return null;
        }
        $query = $this->db->select('*')->from('registration')->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return null;
    }

    function LoginApi($user_name, $password)
    {
    $result = $this->db->query("SELECT user_name,password FROM registration WHERE user_name='$user_name' and password='$password'");
        return $result->result();
    }
    
}