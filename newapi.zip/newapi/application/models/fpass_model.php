<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Fpass_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
       
    function Fpass($user_name)
    {
        $result = $this->db->query("SELECT user_name FROM registration WHERE user_name='$user_name'");
        return $result->result();
    }
    function Fpass1($user_name,$password)
    {
        $result = $this->db->query("UPDATE registration SET password='$password' WHERE user_name='$user_name'");
        return true;
    }
}