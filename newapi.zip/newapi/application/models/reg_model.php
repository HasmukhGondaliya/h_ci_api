<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Reg_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

	function ProfileApi()
    {
        $result = $this->db->query("SELECT * FROM registration");
        return $result->result();
    }

    function RegApi($user_name, $email, $password)
    {
        $this->db->query("INSERT INTO registration(user_name, email, password) VALUES ('$user_name','$email','$password')");
        return true;
    }
	function RegApiCheck($user_name)
    {
        $result = $this->db->query("SELECT user_name, email, password FROM registration WHERE user_name='$user_name'");
        return $result->result();
    }
}