<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Reg_ctrl extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('reg_model');
        $this->load->library('session');
		log_info($this->input->ip_address());
		log_info('Reg_ctrl Controller Class Initialized');
		log_debug('Reg_ctrl Controller Class');
    }

    public function index()
    {
        $this->RegApi();
    }

    public function RegApi()
    {
        $user_name = $this->input->post('user_name');
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $result = $this->reg_model->RegApiCheck($user_name);
        if ($result)
            {
                echo "User already registerd";
                //echo json_encode($result);
				log_message('Username Aleready stored');
            }
        else
            {               
                if($this->reg_model->RegApi($user_name, $email, $password)){
                    echo "Register Successfull";
                } else {
                    echo "Registration failed...!";
                }
            }
        
    }

   
}