<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . '/libraries/REST_Controller.php';

class Logout_ctrl extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('login_model');
        //$this->load->model('reg_model');
        $this->load->library('session');
        log_info($this->input->ip_address());
		log_info('Logout_ctrl Controller Class Initialized');
		log_debug('Logout_ctrl Controller Class');
    }

    public function index(){
		$sess_array = array('user_name' => '');
        $this->session->unset_userdata('logged_in', $sess_array);
        echo "Logout Successfull..!";
    }


}