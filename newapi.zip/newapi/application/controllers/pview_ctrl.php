<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . '/libraries/REST_Controller.php';

class Pview_ctrl extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('login_model');
        $this->load->model('reg_model');
        $this->load->library('session');
        log_info($this->input->ip_address());
		log_info('pview_ctrl Controller Class Initialized');
		log_debug('pview_ctrl Controller Class');
		
    }

    public function index(){
        $this->ProfileApi();          
    }

    public function ProfileApi(){
		
        $result = $this->reg_model->ProfileApi();
        echo json_encode($result);
		
	
    }

    public function index_get()
    {
        $abc = $this->login_model->get();

        if (!is_null($abc)) {
            $this->response(array('response' => $abc), 200);
						
        } else {
			
            $this->response(array('error' => 'No User Found'), 404);
        }
    }

    public function find_get($user_id)
    {
        if (!$user_id) {
            $this->response(null, 400);
        }
        $user = $this->login_model->get($user_id);

        if (!is_null($user)) {
            $this->response(array('response' => $user), 200);
			
        } else {
			log_error('User Not Found in find_get function');
			echo "{
status: 404,
kind: \"Not Found\",
problems: [
{
    code: \"404\",
    title: \"User not found\",
    message: \"User not Found\",
}
}";
            //$this->response(array('error' => 'No User Found'), 404);
        }
    }



}