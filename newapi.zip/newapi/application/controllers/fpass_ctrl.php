<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . '/libraries/REST_Controller.php';

class Fpass_ctrl extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('login_model');
        $this->load->model('fpass_model');
        $this->load->library('session');
        log_info($this->input->ip_address());
		log_info('Fpass_ctrl Controller Class Initialized');
		log_debug('Fpass_ctrl Controller Class');
    }

    public function index()
    {
        $user_name = $this->input->post('user_name');
        $password = $this->input->post('password');
        if($this->fpass_model->Fpass($user_name)){       
            if($this->fpass_model->Fpass1($user_name,$password)){
                echo "Password Changed..!";
            }else{
                echo "Oops..!";
            }
        }else{
			log_error('Fpass_ctrl Username Not Found');
            echo "{
status: 404,
kind: \"Not Found\",
problems: [
{
    code: \"404\",
    title: \"User not found\",
    message: \"User not Found\",
}
}";
        }
       
    }


}