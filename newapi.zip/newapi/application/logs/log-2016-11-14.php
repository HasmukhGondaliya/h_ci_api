
INFO - 2016-11-14 11:42:17 --> Controller Class Initialized
INFO - 2016-11-14 11:42:17 --> ::1
INFO - 2016-11-14 11:42:17 --> Use pview_ctrl Class 
DEBUG - 2016-11-14 11:42:17 --> debug pview_ctrl Class
INFO - 2016-11-14 11:42:17 --> Final output sent to browser
DEBUG - 2016-11-14 11:42:17 --> Total execution time: 0.0740
INFO - 2016-11-14 12:03:52 --> Controller Class Initialized
ERROR - 2016-11-14 12:03:52 --> Invalid Username and Password
INFO - 2016-11-14 12:03:52 --> Final output sent to browser
DEBUG - 2016-11-14 12:03:52 --> Total execution time: 0.0490
INFO - 2016-11-14 12:03:57 --> Controller Class Initialized
ERROR - 2016-11-14 12:03:57 --> Invalid Username and Password
INFO - 2016-11-14 12:03:57 --> Final output sent to browser
DEBUG - 2016-11-14 12:03:57 --> Total execution time: 0.1160
INFO - 2016-11-14 12:04:08 --> Controller Class Initialized
INFO - 2016-11-14 12:04:08 --> ::1
INFO - 2016-11-14 12:04:08 --> Use pview_ctrl Class 
DEBUG - 2016-11-14 12:04:08 --> debug pview_ctrl Class
INFO - 2016-11-14 12:04:08 --> Final output sent to browser
DEBUG - 2016-11-14 12:04:08 --> Total execution time: 0.0510
