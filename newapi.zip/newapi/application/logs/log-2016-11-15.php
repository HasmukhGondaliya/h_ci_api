<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

--------------------------------------------------------------------------------------------------------
2016-11-15 09:28:15 - INFO --> REQUEST_ID = SjUmHt6
2016-11-15 09:28:15 - INFO --> ::1
2016-11-15 09:28:15 - INFO --> pview_ctrl Controller Class Initialized
2016-11-15 09:28:15 - DEBUG --> pview_ctrl Controller Class
2016-11-15 09:28:15 - INFO --> Final output sent to browser
2016-11-15 09:28:15 - DEBUG --> Total execution time: 0.0550
--------------------------------------------------------------------------------------------------------
2016-11-15 09:30:03 - INFO --> REQUEST_ID = NG0bXzm
2016-11-15 09:30:03 - INFO --> ::1
2016-11-15 09:30:03 - INFO --> pview_ctrl Controller Class Initialized
2016-11-15 09:30:03 - DEBUG --> pview_ctrl Controller Class
2016-11-15 09:30:03 - INFO --> Final output sent to browser
2016-11-15 09:30:03 - DEBUG --> Total execution time: 0.0970
--------------------------------------------------------------------------------------------------------
2016-11-15 09:39:48 - INFO --> REQUEST_ID = 1kMeiBb
2016-11-15 09:39:48 - INFO --> ::1
2016-11-15 09:39:48 - INFO --> login_ctrl Controller Class Initialized
2016-11-15 09:39:48 - DEBUG --> login_ctrl Controller Class
2016-11-15 09:39:48 - ERROR --> Invalid Username and Password
2016-11-15 09:39:48 - INFO --> Final output sent to browser
2016-11-15 09:39:48 - DEBUG --> Total execution time: 0.0710
--------------------------------------------------------------------------------------------------------
2016-11-15 09:41:25 - INFO --> REQUEST_ID = 14jQqAD
2016-11-15 09:41:25 - INFO --> ::1
2016-11-15 09:41:25 - INFO --> login_ctrl Controller Class Initialized
2016-11-15 09:41:25 - DEBUG --> login_ctrl Controller Class
2016-11-15 09:41:25 - INFO --> Final output sent to browser
2016-11-15 09:41:25 - DEBUG --> Total execution time: 0.0620
--------------------------------------------------------------------------------------------------------
2016-11-15 09:41:58 - INFO --> REQUEST_ID = qK2umPW
2016-11-15 09:41:58 - INFO --> ::1
2016-11-15 09:41:58 - INFO --> Fpass_ctrl Controller Class Initialized
2016-11-15 09:41:58 - DEBUG --> Fpass_ctrl Controller Class
2016-11-15 09:41:58 - INFO --> Final output sent to browser
2016-11-15 09:41:58 - DEBUG --> Total execution time: 0.0680
--------------------------------------------------------------------------------------------------------
2016-11-15 09:42:11 - INFO --> REQUEST_ID = jEwk5zI
2016-11-15 09:42:12 - INFO --> ::1
2016-11-15 09:42:12 - INFO --> login_ctrl Controller Class Initialized
2016-11-15 09:42:12 - DEBUG --> login_ctrl Controller Class
2016-11-15 09:42:12 - ERROR --> Invalid Username and Password
2016-11-15 09:42:12 - INFO --> Final output sent to browser
2016-11-15 09:42:12 - DEBUG --> Total execution time: 0.0710
--------------------------------------------------------------------------------------------------------
2016-11-15 09:42:15 - INFO --> REQUEST_ID = CPI3TUq
2016-11-15 09:42:15 - INFO --> ::1
2016-11-15 09:42:15 - INFO --> login_ctrl Controller Class Initialized
2016-11-15 09:42:15 - DEBUG --> login_ctrl Controller Class
2016-11-15 09:42:15 - INFO --> Final output sent to browser
2016-11-15 09:42:15 - DEBUG --> Total execution time: 0.0730
--------------------------------------------------------------------------------------------------------

